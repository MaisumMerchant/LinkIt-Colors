#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>
#include <vector>

using namespace sf;
using namespace std;

string level1 = "R G Y|  B W|     | G Y | RBW ";
string level2 = "Y    |     |  G  |BGR Y|R   B";
string level3 = " YBG |   R |  R  |Y  W |B WG ";
string level4 = "   RG|R    |  Y  |   B |GBY  ";
string level5 = "GYM RB|    W |  M   |  R   |G W   |Y B   ";
string level6 = " WB  G|      |  YR G|   M B| RY MW|      ";
string level7 = "      | Y  G |   R  |      |  YBG |  BR  ";
string level8 = "Y     |      |      |RGBG  |YB R  |      ";

string levels[] = {level1, level2, level3, level4, level5, level6, level7, level8};

int currentLevel = 0;

class gameConnection {

	public:
		Color color;
		gameConnection *next;
		int xPos, yPos;

		gameConnection(Color color, int xPos, int yPos) {
			this->color = color;
			this->xPos = xPos;
			this->yPos = yPos;
			this->next = NULL;
		}

};

class gameNode {

	public:
		Color color;
		gameConnection *connection;
		int xPos, yPos;

		gameNode(Color color, int xPos, int yPos) {
			this->color = color;
			this->xPos = xPos;
			this->yPos = yPos;
			this->connection = NULL;
		}

};

vector<gameNode> allGameNodes;
vector<gameConnection> allGameConnections;
vector<CircleShape> gameNodesToDisplay;
vector<RectangleShape> gridLinesToDisplay;
vector<RectangleShape> gameConnectionsToDisplay;
vector<vector<int>> currentPositions;
vector<vector<int>> previousPositions;

int getNoColumns(string level) {
	int noColumns = 0;
	for (int i = 0 ; i < level.length() ; i++) {
		char current = level[i];
		if (current == '|') {
			break;
		}
		noColumns++;
	}
	return noColumns;
}

int getNoRows(string level) {
	int noRows = 1;
	for (int i = 0 ; i < level.length() ; i++) {
		char current = level[i];
		if (current == '|') {
			noRows++;
		}
	}
	return noRows;
}

void makeLevel1(string level) {

	int xPos = 1, yPos = 1;
	for (int i = 0 ; i < level.length() ; i++) {

		char currentEntity = level[i];

		if (currentEntity == '|') {
			yPos++;
			xPos = 0;
		}

		if (currentEntity == 'R') {
			gameNode redNode(Color::Red, xPos, yPos);
			allGameNodes.push_back(redNode);
		}

		if (currentEntity == 'B') {
			gameNode blueNode(Color::Blue, xPos, yPos);
			allGameNodes.push_back(blueNode);
		}

		if (currentEntity == 'Y') {
			gameNode yellowNode(Color::Yellow, xPos, yPos);
			allGameNodes.push_back(yellowNode);
		}

		if (currentEntity == 'W') {
			gameNode whiteNode(Color::White, xPos, yPos);
			allGameNodes.push_back(whiteNode);
		}

		if (currentEntity == 'G') {
			gameNode greenNode(Color::Green, xPos, yPos);
			allGameNodes.push_back(greenNode);
		}

		if (currentEntity == 'M') {
			gameNode magentaNode(Color::Magenta, xPos, yPos);
			allGameNodes.push_back(magentaNode);
		}

		xPos++;

	}

}

void makeLevel2(string level) {

	float nodeSize = 567 / ((3 * getNoColumns(level)) - 1);

	for (int i = 0 ; i < allGameNodes.size() ; i++) {
		CircleShape tempNode(nodeSize);
		gameNodesToDisplay.push_back(tempNode);
		gameNodesToDisplay[i].setPosition((allGameNodes[i].xPos - 1) * (nodeSize * 3) + (100), ((allGameNodes[i].yPos - 1) * (nodeSize * 3)) + (100));
		gameNodesToDisplay[i].setFillColor(allGameNodes[i].color);
	}

	int noGridLines = getNoColumns(level) + getNoRows(level) + 2;
	for (int i = 0 ; i < noGridLines; i++) {
		if (i < noGridLines / 2) {
			RectangleShape tempRect(Vector2f((nodeSize * ((3 * getNoColumns(level)) - 1)) + nodeSize, nodeSize / 25));
			gridLinesToDisplay.push_back(tempRect);
			gridLinesToDisplay[i].setPosition(100 - nodeSize / 2, (i * 3 * nodeSize) + (100) - (nodeSize / 2) - (nodeSize / 50));
		} else {
			RectangleShape tempRect(Vector2f(nodeSize / 25, (nodeSize * ((3 * getNoRows(level)) - 1)) + nodeSize));
			gridLinesToDisplay.push_back(tempRect);
			gridLinesToDisplay[i].setPosition((((i - (noGridLines / 2))) * 3 * nodeSize) + (100) - (nodeSize / 2) - (nodeSize / 50), 100 - nodeSize / 2);
		}
	}

}

void updateConnections(string level) {

	float nodeSize = 567 / ((3 * getNoColumns(level)) - 1);
	gameConnectionsToDisplay.clear();
	for (int i = 0 ; i < allGameConnections.size() ; i++) {
		RectangleShape tempConnection(Vector2f(nodeSize, nodeSize));
		gameConnectionsToDisplay.push_back(tempConnection);
		gameConnectionsToDisplay[i].setPosition((allGameConnections[i].xPos - 1) * (nodeSize * 3) + (100) + (nodeSize / 2), ((allGameConnections[i].yPos - 1) * (nodeSize * 3)) + (100) + (nodeSize / 2));
		gameConnectionsToDisplay[i].setFillColor(allGameConnections[i].color);
	}

}

int getNode(int initXpos, int initYpos) {
	for (int i = 0 ; i < allGameNodes.size() ; i++) {
		if (allGameNodes[i].xPos == initXpos && allGameNodes[i].yPos == initYpos) {
			return i;
		}
	}
	return -1;
}

void makeConnection(int initXpos, int initYpos, int currentXpos, int currentYpos, int prevXpos, int prevYpos, string level) {

	int pointingNode = getNode(initXpos, initYpos);

	if (pointingNode == -1) {

	} else {
		gameNode selectedNode = allGameNodes[pointingNode];
		bool connectionExists = false;
		for (int i = 0 ; i < allGameConnections.size() ; i++) {
			if (allGameConnections[i].xPos == currentXpos && allGameConnections[i].yPos == currentYpos) {
				connectionExists = true;
				break;
			}
		}

		for (int i = 0 ; i < allGameNodes.size() ; i++) {
			if (allGameNodes[i].xPos == currentXpos && allGameNodes[i].yPos == currentYpos) {
				connectionExists = true;
				break;
			}
		}

		if (!connectionExists) {
			gameConnection tempConnection(selectedNode.color, currentXpos, currentYpos);
			allGameConnections.push_back(tempConnection);
			updateConnections(level);
		}

	}

}

void checkForUpdate(int initX, int initY, int currentX, int currentY, string level) {

	int initXpos = 0, initYpos = 0, currentXpos = 0, currentYpos = 0;
	float nodeSize = 567 / ((3 * getNoColumns(level)) - 1);

	for (int i = 0 ; i < getNoColumns(level) ; i++) {
		if (initX > (100 + (i * 3 * (nodeSize))) && initX < (100 + ((i * 3 * (nodeSize)) + 2 * (nodeSize)))) {
			initXpos = i + 1;
		}
		if (currentX > (100 + (i * 3 * (nodeSize))) && currentX < (100 + ((i * 3 * (nodeSize)) + 2 * (nodeSize)))) {
			currentXpos = i + 1;
		}
	}

	for (int i = 0 ; i < getNoRows(level) ; i++) {
		if (initY > (100 + (i * 3 * (nodeSize))) && initY < (100 + ((i * 3 * (nodeSize)) + 2 * (nodeSize)))) {
			initYpos = i + 1;
		}
		if (currentY > (100 + (i * 3 * (nodeSize))) && currentY < (100 + ((i * 3 * (nodeSize)) + 2 * (nodeSize)))) {
			currentYpos = i + 1;
		}
	}

	vector<int> currentPosition = {currentXpos, currentYpos};

	if (count(currentPositions.begin(), currentPositions.end(), currentPosition)) {

	} else {
		if (currentXpos != 0 && currentYpos != 0) {

			if (currentPositions.size() > 0) {
				previousPositions.push_back(currentPositions[0]);
				currentPositions.pop_back();
				makeConnection(initXpos, initYpos, currentXpos, currentYpos, previousPositions[previousPositions.size() - 1][0], previousPositions[previousPositions.size() - 1][1], level);
			}

			for (int i = 0 ; i < previousPositions.size() ; i++) {
				if (previousPositions[i][0] == initXpos && previousPositions[i][1] == initYpos && previousPositions[i][0] == currentXpos && previousPositions[i][1] == currentYpos) {
					for (int j = 0 ; j < allGameConnections.size() ; j++) {
						if (allGameConnections[j].xPos == initXpos && allGameConnections[j].yPos == initYpos) {
							previousPositions.pop_back();
							if (previousPositions.size() > 0) {
								previousPositions.pop_back();
							}
							break;
						}
					}
				}
			}

			for (int i = 0 ; i < previousPositions.size() ; i++) {
				if (currentXpos == previousPositions[i][0] && currentYpos == previousPositions[i][1]) {
					previousPositions.pop_back();
					if (previousPositions.size() > 0) {
						previousPositions.pop_back();
					}
					if (allGameConnections.size() > 0) {
						allGameConnections.pop_back();
					}
					updateConnections(level);
					break;
				}
			}

			currentPositions.push_back(currentPosition);
//			system("cls");
//			cout << "init x : " << initXpos << endl;
//			cout << "init y : " << initYpos << endl;
//			cout << "current x : " << currentPositions[0][0] << endl;
//			cout << "current y : " << currentPositions[0][1] << endl;
//			if (previousPositions.size() > 0) {
//				cout << "prev x : " << previousPositions[previousPositions.size() - 1][0] << endl;
//				cout << "prev y : " << previousPositions[previousPositions.size() - 1][1] << endl;
//			}
//			cout << currentPositions.size() << endl;
//			cout << previousPositions.size() << endl;
//			cout << allGameConnections.size();
		}
	}

}

bool isFinished() {

	int connected = 0;
	for (int i = 0 ; i < allGameNodes.size() ; i++) {
		for (int j = 0 ; j < allGameConnections.size() ; j++) {
			if (allGameNodes[i].xPos + 1 == allGameConnections[j].xPos && allGameNodes[i].yPos == allGameConnections[j].yPos && allGameNodes[i].color == allGameConnections[j].color) {
				connected++;
			} else if (allGameNodes[i].xPos - 1 == allGameConnections[j].xPos && allGameNodes[i].yPos == allGameConnections[j].yPos && allGameNodes[i].color == allGameConnections[j].color) {
				connected++;
			} else if (allGameNodes[i].xPos == allGameConnections[j].xPos && allGameNodes[i].yPos + 1 == allGameConnections[j].yPos && allGameNodes[i].color == allGameConnections[j].color) {
				connected++;
			} else if (allGameNodes[i].xPos == allGameConnections[j].xPos && allGameNodes[i].yPos - 1 == allGameConnections[j].yPos && allGameNodes[i].color == allGameConnections[j].color) {
				connected++;
			}
		}
	}

	if (connected == allGameNodes.size()) {
		return true;
	}

	return false;

}

void showGame() {

	RenderWindow window(VideoMode(), "Link-It Colors", Style::Fullscreen);

	bool buttonPressed = false;
	int initX = 0;
	int initY = 0;
	int currentX = 0;
	int currentY = 0;

	while (window.isOpen()) {

		Font font;
		font.loadFromFile("arial.ttf");

		string displayText;

		if (currentPositions.size() > 0) {
			
			if (previousPositions.size() > 0) {
				displayText = "Current Level : " + to_string(currentLevel + 1) + "\nCurrent X : " + to_string(currentPositions[0][0]) + "\nCurrent Y : " + to_string(currentPositions[0][1]) + "\nPrevious X : " + to_string(previousPositions[previousPositions.size() - 1][0]) + "\nPrevious Y : " + to_string(previousPositions[previousPositions.size() - 1][1]) + "\nNumber Of Previous Positions : " + to_string(previousPositions.size()) + "\nNumber Of Connections : " + to_string(allGameConnections.size());
			} else {
				displayText = "Current Level : " + to_string(currentLevel + 1) + "\nCurrent X : " + to_string(currentPositions[0][0]) + "\nCurrent Y : " + to_string(currentPositions[0][1]) + "\nNumber Of Previous Positions : " + to_string(previousPositions.size()) + "\nNumber Of Connections : " + to_string(allGameConnections.size());
			}
			
		}
		
		Text text(displayText, font);
		text.setCharacterSize(30);
		text.setStyle(Text::Bold);
		text.setFillColor(Color::Red);
		text.setPosition(700, 0);

		Event event;
		while (window.pollEvent(event)) {
		
			if (event.type == Event::Closed) {
				window.close();
			}

			if (event.type == Event::MouseButtonPressed) {
				if (event.mouseButton.button == Mouse::Left) {
					initX = Mouse::getPosition(window).x;
					initY = Mouse::getPosition(window).y;
					buttonPressed = true;
				}
			}

			if (event.type == Event::MouseButtonReleased) {
				if (event.mouseButton.button == Mouse::Left) {
					buttonPressed = false;
				}
			}

			if(buttonPressed) {
				currentX = Mouse::getPosition(window).x;
				currentY = Mouse::getPosition(window).y;
				checkForUpdate(initX, initY, currentX, currentY, levels[currentLevel]);
			}

		}

		window.clear();

		for (int i = 0 ; i < gameNodesToDisplay.size() ; i++) {
			window.draw(gameNodesToDisplay[i]);
		}

		for (int i = 0 ; i < gridLinesToDisplay.size() ; i++) {
			window.draw(gridLinesToDisplay[i]);
		}

		for (int i = 0 ; i < gameConnectionsToDisplay.size() ; i++) {
			window.draw(gameConnectionsToDisplay[i]);
		}

		window.draw(text);

		if (isFinished()) {
			allGameNodes.clear();
			allGameConnections.clear();
			gameConnectionsToDisplay.clear();
			gameNodesToDisplay.clear();
			gridLinesToDisplay.clear();
			currentPositions.clear();
			previousPositions.clear();
			currentLevel += 1;
			if(currentLevel > 8) {
				system("pause");
			}
			makeLevel1(levels[currentLevel]);
			makeLevel2(levels[currentLevel]);
			buttonPressed = false;
		}

		window.display();
		
	}

}

int main() {
	makeLevel1(levels[currentLevel]);
	makeLevel2(levels[currentLevel]);
	showGame();
}
